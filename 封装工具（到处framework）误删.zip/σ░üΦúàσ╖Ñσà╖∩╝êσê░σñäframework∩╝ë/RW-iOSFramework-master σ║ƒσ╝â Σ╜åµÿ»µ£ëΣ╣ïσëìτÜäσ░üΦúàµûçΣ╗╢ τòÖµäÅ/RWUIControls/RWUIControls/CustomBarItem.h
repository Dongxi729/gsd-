//
//  CustomBarItem.h
//  CustomNavigatinItem
//
//  Created by wangtian on 14-11-22.
//  Copyright (c) 2014年 wangtian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

//添加类型
typedef enum{

    left,
    right,
}ItemType;

@interface CustomBarItem : NSObject

@property (nonatomic, strong) UIButton *contentBarItem;
@property (nonatomic, strong) NSMutableArray *items;
@property (nonatomic, assign) ItemType itemType;
@property (nonatomic, strong) UIView *customView;
@property (nonatomic, assign) BOOL isCustomView;

/**
 *  自定义标题
 */
+ (CustomBarItem *)itemWithTitle:(NSString *)title textColor:(UIColor *)color fontSize:(CGFloat)font itemType:(ItemType)type;

/**
 *  设置navigationItem图片
 */
+ (CustomBarItem *)itemWithImage:(NSString *)imageName size:(CGSize)size type:(ItemType)type;

/**
 *  设置选中导航条的类型
 */
- (void)setItemWithNavigationItem:(UINavigationItem *)navigationItem itemType:(ItemType)type;

/**
 *  为左右navigationItem添加单击事件
 */
- (void)addTarget:(id)target selector:(SEL)selector event:(UIControlEvents)event;
/**
 *  设置item偏移量
 *  @param offSet 正值向左偏，负值向右偏
 */
- (void)setOffset:(CGFloat)offSet;
@end
