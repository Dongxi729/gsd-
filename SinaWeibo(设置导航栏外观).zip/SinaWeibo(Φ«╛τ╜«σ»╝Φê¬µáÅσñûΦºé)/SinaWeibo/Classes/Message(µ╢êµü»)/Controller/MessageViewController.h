//
//  MessageViewController.h
//  SinaWeibo
//
//  Created by android_ls on 15/5/17.
//  Copyright (c) 2015年 android_ls. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageViewController : UITableViewController

@end
