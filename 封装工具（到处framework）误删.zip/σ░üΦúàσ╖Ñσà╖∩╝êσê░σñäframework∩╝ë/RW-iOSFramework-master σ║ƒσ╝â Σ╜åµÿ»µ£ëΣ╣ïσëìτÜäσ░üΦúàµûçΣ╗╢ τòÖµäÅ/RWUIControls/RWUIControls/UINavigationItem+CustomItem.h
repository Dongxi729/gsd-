//
//  UINavigationItem+CustomItem.h
//  CustomBarItemDemo
//
//  Created by wangtian on 14-11-22.
//  Copyright (c) 2014年 wangtian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomBarItem.h"
@interface UINavigationItem (CustomItem)

/**
 *  设置navigatoinItem的文字，字体颜色字体大小以及navigationItem是左还是右
 */
- (CustomBarItem *)setItemWithTitle:(NSString *)title textColor:(UIColor *)color fontSize:(CGFloat)font itemType:(ItemType)type;

/**
 *  设置navigatoinItem的图片，图片大小以及navigationItem是左还是右
 */
- (CustomBarItem *)setItemWithImage:(NSString *)imageName size:(CGSize)size itemType:(ItemType)type;

@end
