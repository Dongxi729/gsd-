//
//  FriendAttentionStatusViewController.m
//  SinaWeibo
//
//  Created by android_ls on 15/5/19.
//  Copyright (c) 2015年 android_ls. All rights reserved.
//

#import "FriendAttentionStatusViewController.h"

@interface FriendAttentionStatusViewController ()

@end

@implementation FriendAttentionStatusViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"好友关注动态";

}

@end
