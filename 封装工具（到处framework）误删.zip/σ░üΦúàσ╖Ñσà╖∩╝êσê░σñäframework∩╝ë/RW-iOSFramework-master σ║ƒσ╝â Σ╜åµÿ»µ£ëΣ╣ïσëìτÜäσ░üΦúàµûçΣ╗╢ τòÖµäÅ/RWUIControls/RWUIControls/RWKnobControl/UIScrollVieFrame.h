//
//  UIScrollVieFrame.h
//  iOS
//
//  Created by 郑东喜 on 16/1/7.
//  Copyright © 2016年 RayWenderlich. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  头像地址（暂时地址）
 */
#define heaImgUrlAddress        @"http://pic23.nipic.com/20120918/10031483_133215033311_2.jpg"

/**
 *  背景图片地址
 */
#define backImgUrlAddress       @"http://192.168.6.124/zxtxs/img/zhao_icon/zhao_iconbg.png"

/**
 *  获取屏幕宽度
 *  @param myWidth              屏幕宽度
 *  @param myHeight             屏幕高度
 *  @param pageSize             页码高度
 *  @param pageNum              默认设置当前第3页
 *  @param KCount               滑动子页面个数
 *  @param SCREEN_WIDTH         获取当前屏幕宽度
 *  @param SCREEN_HEIGHT        获取当前屏幕高度
 *  @param SCREEN_MAX_LENGTH    屏幕最大长度
 *  @param SCREEN_MIN_LENGTH    屏幕最小长度
 */

#define kCount 3
#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define SCREEN_MAX_LENGTH (MAX(SCREEN_WIDTH, SCREEN_HEIGHT))
#define SCREEN_MIN_LENGTH (MIN(SCREEN_WIDTH, SCREEN_HEIGHT))

/**
 *  机型识别
 *  @param IS_IPHONE_4_OR_LESS  iPhone4、iPhone4S
 *  @param IS_IPHONE_5          iPhone5、iPhone5S
 *  @param IS_IPHONE_6          iPhone6、iPhone6S
 *  @param IS_IPHONE_6P         iPhone6Plus、iPhone6SPlus
 */
#define IS_IPHONE_4_OR_LESS (SCREEN_MAX_LENGTH < 568.0)
#define IS_IPHONE_5 (SCREEN_MAX_LENGTH == 568.0)
#define IS_IPHONE_6 (SCREEN_MAX_LENGTH == 667.0)
#define IS_IPHONE_6P (SCREEN_MAX_LENGTH == 736.0)

//滑条位置cgcect(x,y,w,h)
/**
 *  子页面左边
 *  @param X                    x轴坐标
 *  @param Y                    y轴左边
 *  @param WIDTH                宽度
 *  @param HEIGHT               高度
 */
#define X 20
#define Y SCREEN_HEIGHT - basicScrollHeight - 20
#define WIDTH SCREEN_WIDTH * 0.7
#define HEIGHT basicScrollHeight - 10

#define basicScrollHeight 120

@interface UIScrollVieFrame : UIView <UIScrollViewDelegate,UIGestureRecognizerDelegate> {
    
    /**
     *  左、中、右滑动页面
     */
    __weak  UIScrollView *_leftScrollView,*_centerScrollView,*_rightScrollView;
    
    /**
     * 主滑动页面
     */
    __weak  UIScrollView *_scrollView;
    
    UIImageView *_headImg;      //头像
    
    UILabel *_nameLabel;        //姓名标签
    
    UILabel *_addLabel;         //地址标签
    
    UIImageView *_backImg;      //背景图片
    
}

/**
 *  初始化滑动视图大小
 *  @param  frame             滑动视图大小（cgrect：CGRectMake(<#CGFloat x#>, <#CGFloat y#>, <#CGFloat width#>, <#CGFloat height#>)）
 */
+ (instancetype)picScrollViewWithFrame:(CGRect)frame ;

@end
