//
//  SetNaviItemBar.m
//  TestCategory
//
//  Created by 郑东喜 on 16/2/29.
//  Copyright © 2016年 郑东喜. All rights reserved.
//

#import "SetNaviItemBar.h"

@implementation SetNaviItemBar

+(instancetype)initWithFrame:(CGRect)frame bgColor:(UIColor *)color {
    return [[SetNaviItemBar alloc] initWithFrame:frame bgColor:color];
}

-(instancetype)initWithFrame:(CGRect)frame bgColor:(UIColor *)color {
    self = [super initWithFrame:frame];
    self.backgroundColor = color;

    return self;
}


- (void)setNavItemWithImg:(NSString *)image addTarget:(id)target btnAction:(SEL)action itemType:(ItemType)type {
    
    UIView *item = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 75)];
    
    if (type == left) {
        self.leftNavButton = [[DockMiddleIcon alloc] initWithFrame:CGRectMake(12, 30, 30, 30)];
        
        self.leftNavButton.imageView.contentMode = UIViewContentModeScaleAspectFit;
        
        [self.leftNavButton setImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
        
        [self.leftNavButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.leftNavButton addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
        
        
    } else if (type == right) {
        self.rightNavButton = [[DockMiddleIcon alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width - 45, 30, 30, 30)];
        self.rightNavButton.imageView.contentMode = UIViewContentModeScaleAspectFit;
        
        [self.rightNavButton setImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
        
        [self.rightNavButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.rightNavButton addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    }
    
 
    
    //加入webview
    //    UIWebView *webView = [[UIWebView alloc] initWithFrame:item.frame];
    //    [item addSubview:webView];
    //    [item insertSubview:webView belowSubview:self.navButton];
    
    [self addSubview:item];
    [item addSubview:self.leftNavButton];
    [item addSubview:self.rightNavButton];
}


@end
