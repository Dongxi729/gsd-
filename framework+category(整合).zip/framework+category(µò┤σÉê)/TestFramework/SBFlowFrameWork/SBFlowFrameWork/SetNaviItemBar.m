//
//  SetNaviItemBar.m
//  TestCategory
//
//  Created by 郑东喜 on 16/2/29.
//  Copyright © 2016年 郑东喜. All rights reserved.
//

#import "SetNaviItemBar.h"

@implementation SetNaviItemBar

+(instancetype)initWithFrame:(CGRect)frame bgColor:(UIColor *)color {
    return [[SetNaviItemBar alloc] initWithFrame:frame bgColor:color];
}

-(instancetype)initWithFrame:(CGRect)frame bgColor:(UIColor *)color {
    self = [super initWithFrame:frame];
    self.backgroundColor = color;

    return self;
}


- (void)setNavItemWithImg:(NSString *)image btnAction:(SEL)action itemType:(ItemType)type {
    
    UIView *item = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 75)];
    
    if (type == left) {
        self.navButton = [[DockMiddleIcon alloc] initWithFrame:CGRectMake(12, 30, 30, 30)];
        
        
    } else if (type == right) {
        self.navButton = [[DockMiddleIcon alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width - 45, 30, 30, 30)];
    }
    
    self.navButton.imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    [self.navButton setImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    
    [self.navButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.navButton addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    
    //加入webview
    //    UIWebView *webView = [[UIWebView alloc] initWithFrame:item.frame];
    //    [item addSubview:webView];
    //    [item insertSubview:webView belowSubview:self.navButton];
    
    [self addSubview:item];
    [item addSubview:self.navButton];
}


-(void)addTarget:(id)target selector:(SEL)selector event:(UIControlEvents)event {
    [self.navButton addTarget:target action:selector forControlEvents:event];
}

@end
