//
//  ZTNavigationController.h
//  SinaWeibo
//
//  Created by chensir on 15/10/13.
//  Copyright (c) 2015年 ZT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZTNavigationController : UINavigationController

@end
