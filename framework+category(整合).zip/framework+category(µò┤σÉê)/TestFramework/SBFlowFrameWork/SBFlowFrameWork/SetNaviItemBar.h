//
//  SetNaviItemBar.h
//  TestCategory
//
//  Created by 郑东喜 on 16/2/29.
//  Copyright © 2016年 郑东喜. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DockMiddleIcon.h"


/**
 *  添加类型
 *  @param  left 导航栏按钮为左边
 *  @param  righ 导航栏按钮为右边
 */
typedef enum{
    left,
    right,
}ItemType;

@interface SetNaviItemBar : UIView  {
    UIButton *_navBtn; //导航栏按钮
}

/**
 *  初始化导航栏（自定义uiview背景颜色及大小）
 */
+(instancetype)initWithFrame:(CGRect)size bgColor:(UIColor *)color;

/**
 *  设置左边导航栏的属性
 *  @param              setNavItemWithImg 设置对应导航栏按钮的图片名称
 *  @param              navBgColor        设置导航栏背景颜色
 *  @param              btnAction         设置导航栏按钮单击事件
 *  @param              itemtype          设置导航栏类型（左边还是右边）
 */
- (void)setNavItemWithImg:(NSString *)image btnAction:(SEL)action itemType:(ItemType)type;

@property (nonatomic,strong) DockMiddleIcon *navButton;

/**
 *  为uiview添加单击事件
 */
- (void)addTarget:(id)target selector:(SEL)selector event:(UIControlEvents)event;

@property (nonatomic, assign) ItemType itemType;


@end
