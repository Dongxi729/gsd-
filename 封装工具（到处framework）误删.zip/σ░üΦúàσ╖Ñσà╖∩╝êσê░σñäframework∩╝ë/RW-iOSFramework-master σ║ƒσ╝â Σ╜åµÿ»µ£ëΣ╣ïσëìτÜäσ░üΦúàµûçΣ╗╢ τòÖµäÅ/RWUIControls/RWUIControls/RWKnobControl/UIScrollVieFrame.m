//
//  UIScrollVieFrame.m
//  iOS
//
//  Created by 郑东喜 on 16/1/7.
//  Copyright © 2016年 RayWenderlich. All rights reserved.
//

#import "UIScrollVieFrame.h"

@implementation UIScrollVieFrame
/**
 *  初始化滑动视图大小
 *  @param  frame             滑动视图大小（cgrect：CGRectMake(<#CGFloat x#>, <#CGFloat y#>, <#CGFloat width#>, <#CGFloat height#>)）
 */
+ (instancetype)picScrollViewWithFrame:(CGRect)frame {
    return  [[UIScrollVieFrame alloc] initWithFrame:frame];
}

- (instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    
    [self prepareScrollView];
    [self prepareImageView];
    
    return self;
}

- (void)prepareScrollView {
    
    UIScrollView *sc = [[UIScrollView alloc] initWithFrame:self.bounds];
    [self addSubview:sc];
    
    _scrollView = sc;
    _scrollView.backgroundColor = [UIColor clearColor];
    _scrollView.pagingEnabled = YES;
    _scrollView.showsHorizontalScrollIndicator = NO;
    _scrollView.delegate = self;
    
    _scrollView.contentSize = CGSizeMake(SCREEN_WIDTH * kCount,0);
    
    for (int i = 1; i<=kCount; i++) {
        // 加载图片
        CGFloat x = (i - 1) * (WIDTH + 20);
        
        //姓名label
        _nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(x + 30, 10, WIDTH * 0.7, 25)];
        [_nameLabel setText:@"1"];
        _nameLabel.layer.borderColor = [UIColor redColor].CGColor;
        _nameLabel.layer.borderWidth = 1;
        [_scrollView addSubview:_nameLabel];
        
        //地址label
        _addLabel = [[UILabel alloc] initWithFrame:CGRectMake(x + 30, 40, WIDTH * 0.7, 25)];
        [_addLabel setText:@"2"];
        _addLabel.layer.borderWidth = 1;
        _addLabel.layer.borderColor = [UIColor grayColor].CGColor;
        [_scrollView addSubview:_addLabel];
        
        //头像
        //机型适配头像大小
        if (IS_IPHONE_4_OR_LESS) {
            _headImg = [[UIImageView alloc] initWithFrame:CGRectMake(x + WIDTH * 0.7 + 30, 10, 50, 50)];
            _headImg.layer.cornerRadius = 25;
        }
        
        if (IS_IPHONE_5) {
            _headImg = [[UIImageView alloc] initWithFrame:CGRectMake(x + WIDTH * 0.7 + 30, 10, 50, 50)];
            _headImg.layer.cornerRadius = 25;
        }
        if (IS_IPHONE_6) {
            _headImg = [[UIImageView alloc] initWithFrame:CGRectMake(x + WIDTH * 0.7 + 30, 10, 60, 60)];
            _headImg.layer.cornerRadius = 30;
        }
        if (IS_IPHONE_6P) {
            _headImg = [[UIImageView alloc] initWithFrame:CGRectMake(x + WIDTH * 0.7 + 30, 10, 70, 70)];
            _headImg.layer.cornerRadius = 35;
        }
        _headImg.layer.masksToBounds = YES;
        _headImg.userInteractionEnabled = YES;
        
        NSURL *heaImgUrl = [NSURL URLWithString:heaImgUrlAddress];
        [_headImg setImage:[UIImage imageWithData:[NSData dataWithContentsOfURL:heaImgUrl]]];
        
        [_scrollView addSubview:_headImg];
        
        _backImg = [[UIImageView alloc] initWithFrame:CGRectMake(x + 20, 0, WIDTH + 5, HEIGHT + 5)];
        NSURL *backImgurl = [NSURL URLWithString:backImgUrlAddress];
        [_backImg setImage:[UIImage imageWithData:[NSData dataWithContentsOfURL:backImgurl]]];
        
        //将图片至于最底层
        [_scrollView insertSubview:_backImg atIndex:0];
    }
    
}


- (void)prepareImageView {
    
    UIScrollView *leftView = [[UIScrollView alloc] initWithFrame:CGRectMake(X, 0, WIDTH, HEIGHT)];
    UIScrollView *currentView = [[UIScrollView alloc] initWithFrame:CGRectMake(2 * X + WIDTH, 0, WIDTH , HEIGHT)];
    UIScrollView *rightView = [[UIScrollView alloc] initWithFrame:CGRectMake(3 * X + WIDTH * 2, 0, WIDTH, HEIGHT)];
    
    currentView.userInteractionEnabled = YES;
    
//    leftView.layer.borderWidth = 1;
//    leftView.layer.borderColor = [UIColor redColor].CGColor;
//    
//    currentView.layer.borderColor = [UIColor greenColor].CGColor;
//    currentView.layer.borderWidth = 1;
//    
//    rightView.layer.borderWidth = 1;
//    rightView.layer.borderColor = [UIColor grayColor].CGColor;
    
    [_scrollView addSubview:leftView];
    [_scrollView addSubview:currentView];
    [_scrollView addSubview:rightView];
    
    _leftScrollView = leftView;
    _centerScrollView = currentView;
    _rightScrollView = rightView;
    
    //    currentView.userInteractionEnabled = YES;
    
}

#pragma mark - 滚动代理
#pragma mark scrollview减速完毕就会调用
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    
    CGFloat pageWidth = scrollView.frame.size.width;
    int currentPage = floor((scrollView.contentOffset.x-pageWidth/2)/pageWidth)+1;
    
    NSLog(@"%d",currentPage);
    
    if (currentPage == 0) {
        UIScrollView *tmpTxtView = _rightScrollView;
        _rightScrollView = _centerScrollView;
        _centerScrollView = _leftScrollView;
        _leftScrollView = tmpTxtView;
    }
    
    if (currentPage == kCount - 1) {
        //换指针
        UIScrollView *tmpTxtView = _leftScrollView;
        _leftScrollView = _centerScrollView;
        _centerScrollView = _rightScrollView;
        _rightScrollView = tmpTxtView;
    }
    
    //恢复原位
    _leftScrollView.frame = CGRectMake(X, 0, WIDTH, HEIGHT);
    _centerScrollView.frame = CGRectMake(2 * X + WIDTH, 0, WIDTH , HEIGHT);
    _rightScrollView.frame = CGRectMake(3 * X + WIDTH * 2, 0, WIDTH, HEIGHT);
    
    //根据机型选择偏移距离
    if (IS_IPHONE_4_OR_LESS) {
        _scrollView.contentOffset = CGPointMake(WIDTH - 10, 0);
    }
    if (IS_IPHONE_5) {
        _scrollView.contentOffset = CGPointMake(WIDTH - 10, 0);
    }
    if (IS_IPHONE_6) {
        _scrollView.contentOffset = CGPointMake(WIDTH - 15, 0);
    }
    if (IS_IPHONE_6P) {
        _scrollView.contentOffset = CGPointMake(WIDTH - 20, 0);
    }
}



@end
