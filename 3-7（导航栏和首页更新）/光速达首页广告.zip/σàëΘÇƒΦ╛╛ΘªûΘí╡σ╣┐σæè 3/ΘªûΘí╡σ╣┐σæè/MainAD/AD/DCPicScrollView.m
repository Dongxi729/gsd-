//
//  DCPicScrollView.m
//  DCPicScrollView
//
//  Created by dengchen on 15/12/4.
//  Copyright © 2015年 name. All rights reserved.
//

#define myWidth self.frame.size.width
#define myHeight self.frame.size.height
#define pageSize (myHeight * 0.2 > 25 ? 25 : myHeight * 0.2)
#define KTitleBlueColor    [UIColor colorWithRed:87/255.0 green:197/255.0 blue:39/255.0 alpha:1]
#define pageTintColor     [UIColor colorWithRed:167/255.0 green:197/255.0 blue:48/255.0 alpha:1]



#import "DCPicScrollView.h"
#import "DCWebImageManager.h"


@interface DCPicScrollView () <UIScrollViewDelegate>

@property (nonatomic,strong) NSMutableDictionary *imageData;

@property (nonatomic,strong) NSArray *imageUrlStrings;

@end



@implementation DCPicScrollView{
    
    __weak  UIImageView *_leftImageView,*_centerImageView,*_rightImageView;
    
    __weak  UILabel *_titleLabel;
    
    __weak  UIScrollView *_scrollView;
    
    __weak  UIPageControl *_PageControl;
    
    NSTimer *_timer;
    
    NSInteger _currentIndex;
    
    NSInteger _MaxImageCount;
    
    BOOL _isNetwork;
    
    BOOL _hasTitle;
}


- (void)setMaxImageCount:(NSInteger)MaxImageCount {
    _MaxImageCount = MaxImageCount;
    
    [self prepareImageView];
    
    [self preparePageControl];
    
    [self setUpTimer];
    
    [self changeImageLeft:_MaxImageCount-1 center:0 right:1];
}


- (void)imageViewDidTap {
    if (self.imageViewDidTapAtIndex != nil) {
        self.imageViewDidTapAtIndex(_currentIndex);
    }
}

+ (instancetype)picScrollViewWithFrame:(CGRect)frame WithImageUrls:(NSArray<NSString *> *)imageUrl {
    return  [[DCPicScrollView alloc] initWithFrame:frame WithImageNames:imageUrl];
}

- (instancetype)initWithFrame:(CGRect)frame WithImageNames:(NSArray<NSString *> *)ImageName {
    if (ImageName.count < 1) {
        return nil;
    }
    
    self = [super initWithFrame:frame];
    
    if(ImageName.count == 1) {
        
        UIImageView *img = [[UIImageView alloc] initWithFrame:self.bounds];
        [self addSubview:img];
        _centerImageView = img;
        
        
        _isNetwork = [ImageName.firstObject hasPrefix:@"http://"];
        
        if (_isNetwork) {
            DCWebImageManager *manager = [DCWebImageManager shareManager];
            
            [manager setDownLoadImageComplish:^(UIImage *image, NSString *url) {
                img.image = image;
            }];
            
            [manager downloadImageWithUrlString:ImageName.firstObject];
            
        }else {
        
            img.image = [UIImage imageNamed:ImageName.firstObject];
        }
    
        return self;
    }
    
    [self prepareScrollView];
    [self setImageUrlStrings:ImageName];
    [self setMaxImageCount:self.imageUrlStrings.count];
    
    return self;
}


- (void)prepareScrollView {
    
    UIScrollView *sc = [[UIScrollView alloc] initWithFrame:self.bounds];
    [self addSubview:sc];
    
    _scrollView = sc;
    _scrollView.backgroundColor = [UIColor clearColor];
    _scrollView.pagingEnabled = YES;
    _scrollView.showsHorizontalScrollIndicator = NO;
    _scrollView.delegate = self;
    
    _scrollView.contentSize = CGSizeMake(myWidth * 3,0);
    
    _AutoScrollDelay = 2.0f;
    _currentIndex = 0;
}

- (void)prepareImageView {
    
    UIImageView *left = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0,myWidth, myHeight)];
    UIImageView *center = [[UIImageView alloc] initWithFrame:CGRectMake(myWidth, 0,myWidth, myHeight)];
    UIImageView *right = [[UIImageView alloc] initWithFrame:CGRectMake(myWidth * 2, 0,myWidth, myHeight)];
    
    center.userInteractionEnabled = YES;
    [center addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageViewDidTap)]];
    
    [_scrollView addSubview:left];
    [_scrollView addSubview:center];
    
    [_scrollView addSubview:right];
    
    _leftImageView = left;
    _centerImageView = center;
    _rightImageView = right;
    
}

- (void)preparePageControl {
    
    UIPageControl *page = [[UIPageControl alloc] initWithFrame:CGRectMake(0,myHeight - pageSize,myWidth, 7)];
    
    page.pageIndicatorTintColor = [UIColor whiteColor];
    page.currentPageIndicatorTintColor = pageTintColor;
    page.numberOfPages = _MaxImageCount;
    page.currentPage = 0;
    
    [self addSubview:page];
    
    
    _PageControl = page;
}



- (void)setPageIndicatorTintColor:(UIColor *)pageIndicatorTintColor {
    _PageControl.pageIndicatorTintColor = pageIndicatorTintColor;
}

- (void)setCurrentPageIndicatorTintColor:(UIColor *)currentPageIndicatorTintColor {
    _PageControl.currentPageIndicatorTintColor = currentPageIndicatorTintColor;
}


#pragma mark scrollViewDelegate
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    [self setUpTimer];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [self removeTimer];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [self changeImageWithOffset:scrollView.contentOffset.x];
}


- (void)changeImageWithOffset:(CGFloat)offsetX {
    
    if (offsetX >= myWidth * 2) {
        _currentIndex++;
        
        if (_currentIndex == _MaxImageCount-1) {
            
            [self changeImageLeft:_currentIndex-1 center:_currentIndex right:0];
            
        }else if (_currentIndex == _MaxImageCount) {
            
            _currentIndex = 0;
            [self changeImageLeft:_MaxImageCount-1 center:0 right:1];
            
        }else {
            [self changeImageLeft:_currentIndex-1 center:_currentIndex right:_currentIndex+1];
        }
        _PageControl.currentPage = _currentIndex;
        
    }
    
    if (offsetX <= 0) {
        _currentIndex--;
        
        if (_currentIndex == 0) {
            
            [self changeImageLeft:_MaxImageCount-1 center:0 right:1];
            
        }else if (_currentIndex == -1) {
            
            _currentIndex = _MaxImageCount-1;
            [self changeImageLeft:_currentIndex-1 center:_currentIndex right:0];
            
        }else {
            [self changeImageLeft:_currentIndex-1 center:_currentIndex right:_currentIndex+1];
        }
        
        _PageControl.currentPage = _currentIndex;
    }
    
}

- (void)changeImageLeft:(NSInteger)LeftIndex center:(NSInteger)centerIndex right:(NSInteger)rightIndex {
    
    
    _leftImageView.image = [self setImageWithIndex:LeftIndex];
    _centerImageView.image = [self setImageWithIndex:centerIndex];
    _rightImageView.image = [self setImageWithIndex:rightIndex];
    

    [_scrollView setContentOffset:CGPointMake(myWidth, 0)];
}

-(void)setPlaceImage:(UIImage *)placeImage {
    if (!_isNetwork) return;
    
    _placeImage = placeImage;
    if (_MaxImageCount < 2 && _centerImageView) {
        _centerImageView.image = _placeImage;
    }else {
        [self changeImageLeft:_MaxImageCount-1 center:0 right:1];
    }
}



- (UIImage *)setImageWithIndex:(NSInteger)index {
    if (index < 0||index >= self.imageUrlStrings.count) {
        return _placeImage;
    }
    //从内存缓存中取,如果没有使用占位图片
    UIImage *image = [self.imageData objectForKey:self.imageUrlStrings[index]];
    
    return image ? image : _placeImage;
}


- (void)scorll {
    [_scrollView setContentOffset:CGPointMake(_scrollView.contentOffset.x + myWidth, 0) animated:YES];
}

- (void)setAutoScrollDelay:(NSTimeInterval)AutoScrollDelay {
    _AutoScrollDelay = AutoScrollDelay;
    [self removeTimer];
    [self setUpTimer];
}

- (void)setUpTimer {
    if (_AutoScrollDelay < 0.5||_timer != nil) return;
    
    _timer = [NSTimer timerWithTimeInterval:_AutoScrollDelay target:self selector:@selector(scorll) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
}

- (void)removeTimer {
    if (_timer == nil) return;
    [_timer invalidate];
    _timer = nil;
}

- (void)setImageUrlStrings:(NSArray *)imageUrlStrings {
    
    _imageUrlStrings = imageUrlStrings;
    _imageData = [NSMutableDictionary dictionaryWithCapacity:_imageUrlStrings.count];
    
    _isNetwork = [imageUrlStrings.firstObject hasPrefix:@"http://"];
    
    if (_isNetwork) {
        
        DCWebImageManager *manager = [DCWebImageManager shareManager];
        
        [manager setDownLoadImageComplish:^(UIImage *image, NSString *url) {
            [self.imageData setObject:image forKey:url];
            [self changeImageLeft:_currentIndex-1 center:_currentIndex right:_currentIndex+1];
        }];
        
        for (NSString *urlSting in imageUrlStrings) {
            [manager downloadImageWithUrlString:urlSting];
        }
        
    }else {
        
        for (NSString *name in imageUrlStrings) {
            [self.imageData setObject:[UIImage imageNamed:name] forKey:name];
        }
        
        
    }
    
}


-(void)dealloc {
    [self removeTimer];
}

@end












