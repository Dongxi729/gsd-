//
//  AppDelegate.h
//  TestFramework
//
//  Created by 郑东喜 on 16/3/1.
//  Copyright © 2016年 郑东喜. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

