//
//  XTZoomPicture.m
//  XTZoomPicture
//
//  Created by TuTu on 15/12/3.
//  Copyright © 2015年 teason. All rights reserved.
//

//#define SIDE_ZOOMTORECT     150.0 //矩形内规则放大
#define FONT_SIZE 14
#import "XTZoomPicture.h"

@interface XTZoomPicture ()

@end

@implementation XTZoomPicture

#pragma mark --
#pragma mark - Initial

/**
 *  初始化backImage
 *
 *  @param frame         视图坐标位置
 *  @param backImage     图片添加的内存地址
 *  @return backImage实例
 */
- (id)initWithFrame:(CGRect)frame
          backImage:(UIImage *)backImage
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setup] ;
//        绘制图片
        self.backImage = backImage ;
    }
    
    return self;
}

/**
 *  创建新的视图对象frame
 *
 *  @param frame         视图坐标位置
 *  @return frame实例
 */

//当我们所写的程序里没用用Nib文件(XIB)时,用代码控制视图内容，需要调用initWithFrame去初始化

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setup] ;
    }
    return self;
}

//用于视图加载nib文件，从nib中加载对象实例时，使用 initWithCoder初始化这些实例对象
- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        [self setup] ;
    }
    return self;
}

- (void)setup
{
    [self srollviewConfigure] ;
    [self imageView] ;
    [self setupGesture] ;
//    添加uiscrollview代理，激活手势事件
    self.delegate = self;
}

- (void)srollviewConfigure
{
    self.maximumZoomScale = MAX_ZOOM;
    self.minimumZoomScale = MIN_ZOOM;
    self.showsHorizontalScrollIndicator = NO;
    self.showsVerticalScrollIndicator   = NO;
    self.backgroundColor = [UIColor blackColor] ;
}

- (void)setupGesture
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
    [self addGestureRecognizer:tap];
    
    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTap:)];
// numberOfTapsRequired：设置需要点击的次数
    doubleTap.numberOfTapsRequired = 2 ;
    [self addGestureRecognizer:doubleTap] ;
    [tap requireGestureRecognizerToFail:doubleTap] ;
}

#pragma mark --
#pragma mark - Property
- (void)setBackImage:(UIImage *)backImage
{
    _backImage = backImage ;
    
    self.imageView.image = backImage ;
}

- (UIImageView *)imageView
{
    if (!_imageView)
    {
        _imageView = [[UIImageView alloc] init] ;
        _imageView.contentMode = UIViewContentModeScaleAspectFit;
        _imageView.backgroundColor = [UIColor blackColor] ;
        _imageView.frame = [self originFrame] ;
        
        if (![_imageView superview]) {
            [self addSubview:_imageView];
        }
    }
    
    return _imageView ;
}

#pragma mark --
- (void)resetToOrigin
{
    [self setZoomScale:1 animated:NO] ;
    self.imageView.frame = [self originFrame] ;
}

- (CGRect)originFrame
{
    CGRect myRect = self.bounds ;
    float flex = FLEX_SIDE ;
    return  CGRectMake(0 + flex, 0 + flex, myRect.size.width - flex * 2, myRect.size.height - flex * 2) ;
}

#pragma mark --
#pragma mark - UIScrollView Delegate
//缩放完毕
- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return self.imageView;
}

#pragma mark - Touch Actions
//单机移除视图
- (void)tap:(UITapGestureRecognizer *)tapGetrue
{
    [self resetToOrigin] ;
    
    [self removeFromSuperview] ;
}

//双机具体方法四个矩形的各个角
- (void)doubleTap:(UITapGestureRecognizer *)tapGesture
{
    if (self.zoomScale >= MAX_ZOOM)
    {
        [self setZoomScale:1 animated:YES] ;
    }
    else
    {
        //locationView
        //返回计算为在由接收机所表示的手势的给定视图中的位置的点。
        //视局部坐标系，用于标识所述手势的位置中的一个点。如果零指定为视图，该方法返回在窗口的基手势位置坐标系统
        CGPoint point = [tapGesture locationInView:self] ;
        //zoomToRect:
        //缩放到内容的特定区域，以便它是在接收机中可见。
        //此方法放大，使得内容视图变成由矩形限定的区域，调整zoomScale是必要的。
        [self zoomToRect:CGRectMake(point.x - SIDE_ZOOMTORECT / 2, point.y - SIDE_ZOOMTORECT / 2, SIDE_ZOOMTORECT, SIDE_ZOOMTORECT) animated:YES];
    }
}

@end
