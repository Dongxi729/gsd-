//
//  DockMiddleIcon.h
//  TabBarView
//
//  Created by 郑东喜 on 16/2/25.
//  Copyright © 2016年 郑东喜. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DockMiddleIcon : UIButton

@end
