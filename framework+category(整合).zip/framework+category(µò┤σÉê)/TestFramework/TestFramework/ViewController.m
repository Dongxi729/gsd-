//
//  ViewController.m
//  TestFramework
//
//  Created by 郑东喜 on 16/3/1.
//  Copyright © 2016年 郑东喜. All rights reserved.
//

#import "ViewController.h"
#import <SBFlowFrameWork/SBFlowFrameWork.h>
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    DockMiddleIcon * dcl = [[DockMiddleIcon alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    [dcl setImage:[UIImage imageNamed:@"1.png"] forState:UIControlStateNormal];
    
    dcl.layer.borderWidth = 0.5;
    
    [self.view addSubview:dcl];
    
    CustomBarItem *leftItem = [self.navigationItem setItemWithTitle:@"hello" textColor:[UIColor blackColor] fontsize:14 itemType:left];
    [leftItem setOffset:10];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
